# Klarer Kopf – 10 Übungen gegen Brainfog

Eine interaktive Web-App von [Mein Veränderungsweg](https://veraenderungsweg.de)

---

## Was ist das?

Eine sofort nutzbare HTML-App mit 10 kurzen Übungen (1–3 Min.) zur Selbstregulation bei mentalem Brainfog. Kein Login, keine Installation, keine Cloud – alles läuft direkt im Browser.

## Funktionen

- 10 Übungen sortiert nach Sofortwirkung
- Zu jeder Übung: Anleitung, Wirkung, passender Moment
- Eingebauter Timer pro Übung
- „Erledigt"-Markierung und persönliche Notiz
- Fortschrittsanzeige
- 5-Minuten-Notfall-Routine
- Alle Eingaben werden lokal gespeichert (localStorage)

## Technisches

- Einzelne HTML-Datei – kein Framework, kein Build-Schritt
- Fonts via Google Fonts (Cormorant Garamond + Jost)
- Funktioniert offline nach dem ersten Laden
- GitHub Pages kompatibel

## Deployment auf GitHub Pages

1. Dieses Repository forken oder hochladen
2. In den Repository-Einstellungen → **Pages** → Source: `main` / `root`
3. Die App ist dann erreichbar unter `https://[dein-username].github.io/[repo-name]/`

## Lizenz

© Tanja · veraenderungsweg.de  
Alle Rechte vorbehalten. Nicht zur kommerziellen Weiterverwendung.
